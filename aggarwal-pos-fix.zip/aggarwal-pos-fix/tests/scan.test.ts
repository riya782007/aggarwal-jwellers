import { describe, expect, it } from "vitest";
import { skuCandidatesFromScan, looksLikeSkuScan, normalizeScanPayload } from "../lib/scan";

describe("scanner SKU normalization", () => {
  it("keeps the literal scan and adds a dash-separated fallback for legacy labels", () => {
    const c = skuCandidatesFromScan(" K12 A78271305 ");
    expect(c[0]).toBe("K12 A78271305");
    expect(c).toContain("K12-A78271305");
  });

  it("extracts encoded SKUs from existing product-page QR labels", () => {
    expect(skuCandidatesFromScan("https://aggarwaljewellers.in/p/AJ1004%2FRED")).toEqual(
      expect.arrayContaining(["AJ1004/RED"]),
    );
    expect(skuCandidatesFromScan("https://aggarwaljewellers.in/p/AJ1004%2FRED")[0]).toBe("AJ1004/RED");
  });

  it("does not lose an already normalized SKU value", () => {
    expect(skuCandidatesFromScan("AJ1004-RED")[0]).toBe("AJ1004-RED");
  });

  it("strips Code-39 asterisk wrappers and control characters from wedge scanners", () => {
    expect(normalizeScanPayload("\u0002*AJ1004-RED*\r")).toBe("AJ1004-RED");
    expect(skuCandidatesFromScan("*AJ1004-RED*")[0]).toBe("AJ1004-RED");
  });

  it("treats compact alphanumeric payloads as SKU scans, not name search", () => {
    expect(looksLikeSkuScan("AJ1004-RED")).toBe(true);
    expect(looksLikeSkuScan("kundan necklace")).toBe(false);
  });
});

import { canonicalSku, longestSkuToken, variantLabel } from "../lib/scan";

describe("separator-blind SKU matching (bangle sizes)", () => {
  it("treats dots, dashes, spaces, NBSP and en-dashes as the same SKU", () => {
    const want = "A3SAJNI13124MHWT210";
    for (const s of ["A3SAJNI13124MHWT-210", "A3SAJNI13124MHWT-2.10", "a3sajni13124mhwt 210 ", "A3SAJNI13124MHWT\u2013210", "A3SAJNI13124MHWT-210\u00a0"]) {
      expect(canonicalSku(s)).toBe(want);
    }
  });
  it("keeps different sizes different", () => {
    expect(canonicalSku("A3SAJNI13124MHWT-28")).not.toBe(canonicalSku("A3SAJNI13124MHWT-210"));
    expect(canonicalSku("A3SAJNI13124MHWT-24")).not.toBe(canonicalSku("A3SAJNI13124MHWT-26"));
  });
  it("picks the design code as the search token", () => {
    expect(longestSkuToken("A3SAJNI13124MHWT-210")).toBe("A3SAJNI13124MHWT");
  });
  it("names every size on the bill", () => {
    expect(variantLabel("STONE 4PC BANGLE", { size: "2.10" })).toBe("STONE 4PC BANGLE · 2.10");
    expect(variantLabel("STONE 4PC BANGLE", { color: "Red", size: "2.4" })).toBe("STONE 4PC BANGLE · Red · 2.4");
    expect(variantLabel("RING", {})).toBe("RING");
  });
});
